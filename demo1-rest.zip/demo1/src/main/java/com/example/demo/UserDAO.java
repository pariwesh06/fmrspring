package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class UserDAO implements IUserDAO {
	@Autowired
	JdbcTemplate jdbcTemplate; // dependency

	public void save(User user) throws Exception {
		System.out.println("Called###     " + jdbcTemplate);
		jdbcTemplate.execute("INSERT INTO user (name, age) values('" + user.getName() + "'," + user.getAge() + ")");
//		throw new Exception();
	}

	@Override
	public List<User> get() {
		return jdbcTemplate.query("select * from user", new RowMapper<User>() {

			@Override
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				User user = new User();
				System.out.println(rowNum);
				user.setName(rs.getString("name"));
				user.setAge(rs.getByte("age"));
				return user;
			}
		});
	}

	@Override
	public void delete(int id) {
		jdbcTemplate.execute("DELETE FROM USER WHERE ID=" + id);
	}

}

// 1. update pom.xml
// 2. define 2 beans
// 3. inject JDBCtemplate into DAO class.