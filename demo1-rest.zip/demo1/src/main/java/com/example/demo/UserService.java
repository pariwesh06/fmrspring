package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class UserService {
	// @Autowired//field DI
	private IUserDAO userDAO;// dependency, tight coupling
	@Autowired
	private IAccountDAO accountDAO;

	public IAccountDAO getAccountDAO() {
		return accountDAO;
	}

	public IUserDAO getUserDAO() {
		return userDAO;
	}
	/*
	 * public UserService(IUserDAO userDAO, IAccountDAO accountDAO) {
	 * this.userDAO=userDAO; this.accountDAO=accountDAO; }
	 */

	// Constructor DI
	@Deprecated
	public UserService(IUserDAO userDAO) {
		this.userDAO = userDAO;
	}

	public void delete1(int id) {
		userDAO.delete(id);
	}
	/*
	 * @Autowired //setter DI public void setUserDAO(IUserDAO userDAO) {
	 * this.userDAO = userDAO; }
	 */
	@Transactional(rollbackFor = { Exception.class }, noRollbackFor = { NumberFormatException.class,
			IllegalArgumentException.class })
	public void save1(User user) throws Exception {
		
		userDAO.save(user);
	}

	public List<User> get() {
		return userDAO.get();
	}
}
