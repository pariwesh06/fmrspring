package com.example.demo;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@SpringBootApplication  //it configures Dispatcherservlet automatically
public class Config {
	// @Bean
	@Bean
	public PlatformTransactionManager transactionManager() {
		return new DataSourceTransactionManager(dataSource);
	}
	// public UserDAOStub userDAOStub() {
	// return new UserDAOStub();
	// }
	@Autowired
	DataSource dataSource;

	@Bean
	public DataSource dataSource(@Value("${dbUrl}") String dbUrl, @Value("${login}") String login,
			@Value("${password}") String password) {
		return new DriverManagerDataSource(dbUrl, login, password);
	}
	@Bean
	public JdbcTemplate jdbcTemplate() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(dataSource);
		return jdbcTemplate;
	}

	@Bean
	public AccountDAO accountDAO() {
		return new AccountDAO();
	}

	@Bean
	public UserDAO userDAO() {// bean method
		return new UserDAO();
	}

	@Bean
	public UserService userService() {
		return new UserService(userDAO());
	}
}
