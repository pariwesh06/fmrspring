package com.example.demo;

import java.util.List;

public class UserDAOStub implements IUserDAO {

	@Override
	public void save(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<User> get() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

}
