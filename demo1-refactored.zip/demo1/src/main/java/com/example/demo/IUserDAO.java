package com.example.demo;

import java.util.List;

public interface IUserDAO {
	void save(User user) throws Exception;
	public List<User> get() ;
	void delete(int id);
	List<User> find(String name);
}
