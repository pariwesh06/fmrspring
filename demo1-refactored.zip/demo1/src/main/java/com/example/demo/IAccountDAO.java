package com.example.demo;

public interface IAccountDAO {

}
