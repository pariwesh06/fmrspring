package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

public class Main {
	public static void main(String[] args) {
		ApplicationContext applicationContext = SpringApplication.run(Config.class);
		
//		UserDAO userDAO = applicationContext.getBean(UserDAO.class);
//		UserDAO userDAO1 = applicationContext.getBean(UserDAO.class);
		
//		System.out.println(userDAO==userDAO1);
		UserService userService = applicationContext.getBean(UserService.class);
		userService.save1();
//		System.out.println("dao is "+userService.getAccountDAO());
//		userDAO.save();
	}
}
