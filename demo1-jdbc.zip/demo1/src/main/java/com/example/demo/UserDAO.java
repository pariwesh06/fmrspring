package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class UserDAO implements IUserDAO{
	@Autowired
	JdbcTemplate jdbcTemplate; //dependency
	public void save() {
		System.out.println("Called###     "+ jdbcTemplate);
		jdbcTemplate.execute("INSERT INTO user (name, age) values('Ram', 23)");
	}
}
