package com.example.demo;

import java.util.List;

public class User {
	String name;
	byte age;
	List<Account> accounts;
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
}
