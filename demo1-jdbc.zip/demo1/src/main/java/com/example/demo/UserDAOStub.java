package com.example.demo;

public class UserDAOStub implements IUserDAO {

	@Override
	public void save() {
		// TODO Auto-generated method stub
		
	}

}
