package com.example.demo;

public interface IUserDAO {
	void save();
}
