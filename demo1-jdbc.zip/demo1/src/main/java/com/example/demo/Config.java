package com.example.demo;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class Config {
//	@Bean
//	public UserDAOStub userDAOStub() {
//		return new UserDAOStub();
//	}
	@Bean
	public AccountDAO accountDAO() {
		return new AccountDAO();
	}
	@Bean
	public UserDAO userDAO() {//bean method
		return new UserDAO();
	}
	@Bean
	public UserService userService() {
		return new UserService(userDAO());
	}
	@Bean
	public DataSource dataSource() {
		return new DriverManagerDataSource("jdbc:mysql://localhost:3306/fmr", 
				"root", "");
	}
	@Bean
	public JdbcTemplate	jdbcTemplate() {
		return new JdbcTemplate(dataSource());
	}
}











