package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class UserService {
//	@Autowired//field DI
	private IUserDAO userDAO;//dependency,  tight coupling
	@Autowired
	private IAccountDAO accountDAO;
	public IAccountDAO getAccountDAO() {
		return accountDAO;
	}

	public IUserDAO getUserDAO() {
		return userDAO;
	}
/*	public UserService(IUserDAO userDAO, IAccountDAO accountDAO) {
		this.userDAO=userDAO;
		this.accountDAO=accountDAO;
	}*/
	
	//Constructor DI
	@Deprecated
	public UserService(IUserDAO userDAO) {
		this.userDAO=userDAO;
	}
	
	/*@Autowired //setter DI
	public void setUserDAO(IUserDAO userDAO) {
		this.userDAO = userDAO;
	}*/

	public void save1() {
		userDAO.save();
	}
}
