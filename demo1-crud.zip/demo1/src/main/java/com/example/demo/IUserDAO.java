package com.example.demo;

import java.util.List;

public interface IUserDAO {
	void save(User user);
	public List<User> get() ;
}
